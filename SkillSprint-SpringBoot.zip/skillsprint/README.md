# SkillSprint

A beginner-friendly full-stack Spring Boot project for tracking personal upskilling.

## Features
- Add, view, update and delete skills
- Search by skill/category
- Filter by status
- Dashboard totals and average progress
- Validation and global exception handling
- Persistent H2 database
- Responsive HTML/CSS/JavaScript frontend

## Requirements
- Java 17+
- Maven 3.6+

## Run
```bash
mvn spring-boot:run
```
Open: http://localhost:8080

## H2 Console
Open: http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:file:./data/skillsprintdb
- User: sa
- Password: leave blank

## Main APIs
- POST /api/skills
- GET /api/skills
- GET /api/skills/{id}
- PUT /api/skills/{id}
- DELETE /api/skills/{id}
- GET /api/skills/dashboard
- GET /api/skills?status=IN_PROGRESS
- GET /api/skills?search=java

## Example JSON
```json
{
  "name": "Java Spring Boot",
  "category": "Backend",
  "progress": 50,
  "status": "IN_PROGRESS",
  "learningHours": 10,
  "targetDate": "2026-10-20",
  "notes": "REST API and JPA practice"
}
```

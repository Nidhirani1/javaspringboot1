package com.nidhi.skillsprint.dto;

public record DashboardResponse(
        long totalSkills,
        long completedSkills,
        long inProgressSkills,
        int totalLearningHours,
        double averageProgress
) {}

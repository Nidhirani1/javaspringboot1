package com.nidhi.skillsprint.repository;

import com.nidhi.skillsprint.entity.Skill;
import com.nidhi.skillsprint.entity.SkillStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SkillRepository extends JpaRepository<Skill, Long> {
    List<Skill> findByStatusOrderByNameAsc(SkillStatus status);
    List<Skill> findByNameContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrderByNameAsc(
            String name, String category);
    long countByStatus(SkillStatus status);
}

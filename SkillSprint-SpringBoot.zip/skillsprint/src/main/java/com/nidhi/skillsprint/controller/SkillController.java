package com.nidhi.skillsprint.controller;

import com.nidhi.skillsprint.dto.DashboardResponse;
import com.nidhi.skillsprint.dto.SkillRequest;
import com.nidhi.skillsprint.entity.Skill;
import com.nidhi.skillsprint.entity.SkillStatus;
import com.nidhi.skillsprint.service.SkillService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/skills")
public class SkillController {
    private final SkillService service;

    public SkillController(SkillService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Skill> create(@Valid @RequestBody SkillRequest request) {
        Skill created = service.create(request);
        return ResponseEntity.created(URI.create("/api/skills/" + created.getId())).body(created);
    }

    @GetMapping
    public List<Skill> getAll(
            @RequestParam(required = false) SkillStatus status,
            @RequestParam(required = false) String search) {
        return service.getAll(status, search);
    }

    @GetMapping("/{id}")
    public Skill getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PutMapping("/{id}")
    public Skill update(@PathVariable Long id, @Valid @RequestBody SkillRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/dashboard")
    public DashboardResponse dashboard() {
        return service.dashboard();
    }
}

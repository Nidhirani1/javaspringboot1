package com.nidhi.skillsprint.entity;

public enum SkillStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}

package com.nidhi.skillsprint.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "skills")
public class Skill {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String name;

    @Column(nullable = false, length = 50)
    private String category;

    @Column(nullable = false)
    private Integer progress;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private SkillStatus status;

    private Integer learningHours;
    private LocalDate targetDate;

    @Column(length = 500)
    private String notes;

    public Skill() {}

    public Skill(String name, String category, Integer progress, SkillStatus status,
                 Integer learningHours, LocalDate targetDate, String notes) {
        this.name = name;
        this.category = category;
        this.progress = progress;
        this.status = status;
        this.learningHours = learningHours;
        this.targetDate = targetDate;
        this.notes = notes;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public Integer getProgress() { return progress; }
    public void setProgress(Integer progress) { this.progress = progress; }
    public SkillStatus getStatus() { return status; }
    public void setStatus(SkillStatus status) { this.status = status; }
    public Integer getLearningHours() { return learningHours; }
    public void setLearningHours(Integer learningHours) { this.learningHours = learningHours; }
    public LocalDate getTargetDate() { return targetDate; }
    public void setTargetDate(LocalDate targetDate) { this.targetDate = targetDate; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}

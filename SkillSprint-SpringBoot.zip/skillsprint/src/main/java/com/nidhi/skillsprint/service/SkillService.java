package com.nidhi.skillsprint.service;

import com.nidhi.skillsprint.dto.DashboardResponse;
import com.nidhi.skillsprint.dto.SkillRequest;
import com.nidhi.skillsprint.entity.Skill;
import com.nidhi.skillsprint.entity.SkillStatus;
import com.nidhi.skillsprint.exception.ResourceNotFoundException;
import com.nidhi.skillsprint.repository.SkillRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class SkillService {
    private final SkillRepository repository;

    public SkillService(SkillRepository repository) {
        this.repository = repository;
    }

    public Skill create(SkillRequest request) {
        Skill skill = new Skill();
        copy(request, skill);
        return repository.save(skill);
    }

    @Transactional(readOnly = true)
    public List<Skill> getAll(SkillStatus status, String search) {
        if (search != null && !search.isBlank()) {
            String text = search.trim();
            return repository.findByNameContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrderByNameAsc(text, text);
        }
        if (status != null) {
            return repository.findByStatusOrderByNameAsc(status);
        }
        return repository.findAll(Sort.by(Sort.Direction.ASC, "name"));
    }

    @Transactional(readOnly = true)
    public Skill getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Skill not found with id: " + id));
    }

    public Skill update(Long id, SkillRequest request) {
        Skill skill = getById(id);
        copy(request, skill);
        return repository.save(skill);
    }

    public void delete(Long id) {
        Skill skill = getById(id);
        repository.delete(skill);
    }

    @Transactional(readOnly = true)
    public DashboardResponse dashboard() {
        List<Skill> skills = repository.findAll();
        int hours = skills.stream()
                .mapToInt(skill -> skill.getLearningHours() == null ? 0 : skill.getLearningHours())
                .sum();
        double average = skills.stream()
                .mapToInt(Skill::getProgress)
                .average()
                .orElse(0.0);
        return new DashboardResponse(
                skills.size(),
                repository.countByStatus(SkillStatus.COMPLETED),
                repository.countByStatus(SkillStatus.IN_PROGRESS),
                hours,
                Math.round(average * 100.0) / 100.0
        );
    }

    private void copy(SkillRequest request, Skill skill) {
        skill.setName(request.name().trim());
        skill.setCategory(request.category().trim());
        skill.setProgress(request.progress());
        skill.setStatus(request.progress() == 100 ? SkillStatus.COMPLETED : request.status());
        skill.setLearningHours(request.learningHours());
        skill.setTargetDate(request.targetDate());
        skill.setNotes(request.notes() == null ? "" : request.notes().trim());
    }
}

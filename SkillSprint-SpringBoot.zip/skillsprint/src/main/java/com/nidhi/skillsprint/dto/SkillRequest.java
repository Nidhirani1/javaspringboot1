package com.nidhi.skillsprint.dto;

import com.nidhi.skillsprint.entity.SkillStatus;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

public record SkillRequest(
        @NotBlank(message = "Skill name is required")
        @Size(max = 80, message = "Skill name must be at most 80 characters")
        String name,

        @NotBlank(message = "Category is required")
        @Size(max = 50, message = "Category must be at most 50 characters")
        String category,

        @NotNull(message = "Progress is required")
        @Min(value = 0, message = "Progress cannot be below 0")
        @Max(value = 100, message = "Progress cannot exceed 100")
        Integer progress,

        @NotNull(message = "Status is required")
        SkillStatus status,

        @NotNull(message = "Learning hours are required")
        @Min(value = 0, message = "Learning hours cannot be negative")
        Integer learningHours,

        LocalDate targetDate,

        @Size(max = 500, message = "Notes must be at most 500 characters")
        String notes
) {}

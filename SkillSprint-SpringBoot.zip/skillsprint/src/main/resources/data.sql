INSERT INTO skills (name, category, progress, status, learning_hours, target_date, notes)
SELECT 'Spring Boot', 'Backend', 45, 'IN_PROGRESS', 8, DATE '2026-10-15', 'Learning REST APIs and JPA'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Spring Boot');

INSERT INTO skills (name, category, progress, status, learning_hours, target_date, notes)
SELECT 'Generative AI', 'AI', 70, 'IN_PROGRESS', 15, DATE '2026-10-30', 'Practising LLM and RAG concepts'
WHERE NOT EXISTS (SELECT 1 FROM skills WHERE name = 'Generative AI');

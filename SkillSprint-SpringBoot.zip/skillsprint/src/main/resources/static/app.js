const API = '/api/skills';
const list = document.getElementById('skillList');
const dialog = document.getElementById('skillDialog');
const form = document.getElementById('skillForm');
const message = document.getElementById('message');

async function request(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Request failed' }));
    const details = error.errors ? Object.values(error.errors).join(', ') : error.message;
    throw new Error(details || 'Request failed');
  }
  return response.status === 204 ? null : response.json();
}

async function loadSkills() {
  const search = document.getElementById('search').value.trim();
  const status = document.getElementById('filter').value;
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (status) params.set('status', status);
  const skills = await request(`${API}?${params}`);
  renderSkills(skills);
}

async function loadDashboard() {
  const data = await request(`${API}/dashboard`);
  document.getElementById('totalSkills').textContent = data.totalSkills;
  document.getElementById('completedSkills').textContent = data.completedSkills;
  document.getElementById('inProgressSkills').textContent = data.inProgressSkills;
  document.getElementById('totalHours').textContent = data.totalLearningHours;
  document.getElementById('averageProgress').textContent = `${data.averageProgress}%`;
}

function renderSkills(skills) {
  if (!skills.length) {
    list.innerHTML = '<div class="empty">No skills found. Add your first learning goal.</div>';
    return;
  }
  list.innerHTML = skills.map(skill => `
    <article class="skill-card">
      <div style="display:flex;justify-content:space-between;gap:12px">
        <div><h3>${escapeHtml(skill.name)}</h3><p class="muted">${escapeHtml(skill.category)}</p></div>
        <span class="badge">${formatStatus(skill.status)}</span>
      </div>
      <div class="progress"><div style="width:${skill.progress}%"></div></div>
      <strong>${skill.progress}% complete</strong>
      <p class="muted">Hours: ${skill.learningHours} | Target: ${skill.targetDate || 'Not set'}</p>
      <p>${escapeHtml(skill.notes || 'No notes')}</p>
      <div class="card-actions">
        <button onclick='editSkill(${JSON.stringify(skill)})'>Edit</button>
        <button class="delete" onclick="deleteSkill(${skill.id})">Delete</button>
      </div>
    </article>`).join('');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
}
function formatStatus(status) { return status.replaceAll('_', ' '); }
function showMessage(text, isError = false) { message.style.color = isError ? '#b91c1c' : '#047857'; message.textContent = text; setTimeout(() => message.textContent = '', 3000); }

function openNew() {
  form.reset();
  document.getElementById('skillId').value = '';
  document.getElementById('progress').value = 0;
  document.getElementById('learningHours').value = 0;
  document.getElementById('formTitle').textContent = 'Add Skill';
  dialog.showModal();
}
window.editSkill = function(skill) {
  document.getElementById('skillId').value = skill.id;
  document.getElementById('name').value = skill.name;
  document.getElementById('category').value = skill.category;
  document.getElementById('progress').value = skill.progress;
  document.getElementById('status').value = skill.status;
  document.getElementById('learningHours').value = skill.learningHours;
  document.getElementById('targetDate').value = skill.targetDate || '';
  document.getElementById('notes').value = skill.notes || '';
  document.getElementById('formTitle').textContent = 'Edit Skill';
  dialog.showModal();
};
window.deleteSkill = async function(id) {
  if (!confirm('Delete this skill?')) return;
  try { await request(`${API}/${id}`, { method: 'DELETE' }); showMessage('Skill deleted'); await refresh(); }
  catch (error) { showMessage(error.message, true); }
};

form.addEventListener('submit', async event => {
  event.preventDefault();
  const id = document.getElementById('skillId').value;
  const payload = {
    name: document.getElementById('name').value,
    category: document.getElementById('category').value,
    progress: Number(document.getElementById('progress').value),
    status: document.getElementById('status').value,
    learningHours: Number(document.getElementById('learningHours').value),
    targetDate: document.getElementById('targetDate').value || null,
    notes: document.getElementById('notes').value
  };
  try {
    await request(id ? `${API}/${id}` : API, {
      method: id ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    dialog.close(); showMessage(id ? 'Skill updated' : 'Skill added'); await refresh();
  } catch (error) { showMessage(error.message, true); }
});

async function refresh() { await Promise.all([loadSkills(), loadDashboard()]); }
document.getElementById('newBtn').addEventListener('click', openNew);
document.getElementById('cancelBtn').addEventListener('click', () => dialog.close());
document.getElementById('search').addEventListener('input', loadSkills);
document.getElementById('filter').addEventListener('change', loadSkills);
refresh().catch(error => showMessage(error.message, true));
